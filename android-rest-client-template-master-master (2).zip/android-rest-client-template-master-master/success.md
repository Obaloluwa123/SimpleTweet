## OAUTH CALLBACK SUCCESSFUL

If you see this page, the OAuth callback succeeded.  Because you are possibly using Android 7.0+, Twitter's redirect may not be working correctly.

Switch back to your Android app and try to login again!

If you are using the default callback URL provided in this project, clicking this [oauth://cprest](oauth://cprest) link should close the app.

For more details, see:

* [https://twittercommunity.com/t/implementing-web-based-oauth-flow-with-twitter-api-breaks-for-android-nougat-api-25/86821](https://twittercommunity.com/t/implementing-web-based-oauth-flow-with-twitter-api-breaks-for-android-nougat-api-25/86821)
* [https://developer.chrome.com/multidevice/android/intents](https://developer.chrome.com/multidevice/android/intents)